﻿using NewApartment;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer
{
    
        public interface IDataComponent
        {
            bool RegisterCustomer(string mailid, string name, string Password);
            bool UpdateCustomer(string mailid, string name, string Password);
            int CustomerLogin(string mailid, string password);
            bool deleteCustomer(string mailid);
            List<Customer> GetAllCustomers();
            Customer customerId(string mailId);

            List<Rent> GetAllRents();
            bool clearRent(int id);


            List<Tenant> GetAllTenants();
            bool JoinTenants(string address, string city, string state, string mail, long phone);
            bool UpdateTenant(int Customerid, string address, string city, string state, string mail, long phone);
            bool Deletetenant(string mailId);
           
            
            List<Allotment> GetAllotments();
            bool Allot(int tenantid, int people, int area);
            bool deleteAllot(int Allotid);
            bool Allotupdate(int tenantid, int people, int area);

            bool problem(int tenantid, string query, string status);
            List<Query> getAllproblems();
            bool UpdateQuerytosolve(int id);

            List<Gym_record> getGymrecords();
            bool Gym(int tenantid, string status, DateTime date);

            List<Swimming_record> getswimminRecords();
            bool swimming(int tenantid, string status, DateTime date);

            List<FamilyClub> getprogrammeRecords();
            bool familyclub(int roomno, DateTime bookingdate, DateTime bookinglast);
        }

        public class DataComponent : IDataComponent
        {
            static DataEntities db = new DataEntities();

            public bool Allot(int tenantid, int people, int area)
            {
                try
                {
                    Allotment allot = new Allotment()
                    {
                        TenantId = tenantid,
                        Number_of_people = people,
                        Area_of_Room_in_sqf = area
                    };
                    db.Allotments.Add(allot);
                    db.SaveChanges();
                    return true;
                }
                catch (Exception)
                {

                    return false;
                }
            }

            public bool Allotupdate(int tenantid, int people, int area)
            {
                try
                {
                    Allotment allot = db.Allotments.FirstOrDefault((c) => c.TenantId == tenantid);
                    allot.Number_of_people = people;
                    allot.Area_of_Room_in_sqf = area;
                    db.SaveChanges();
                    return true;
                }
                catch (Exception)
                {

                    return false;
                }
            }


            public bool familyclub(int roomno, DateTime bookingdate, DateTime bookinglast)
            {
                try
                {
                    if (bookingdate != Convert.ToDateTime(db.FamilyClubs.OrderBy(u => u.date_of_ending).Take(1)))
                    {
                        FamilyClub familyClub = new FamilyClub()
                        {
                            RoomNo = roomno,
                            date_Booked = bookingdate,
                            date_of_ending = bookinglast
                        };
                        db.FamilyClubs.Add(familyClub);
                        db.SaveChanges();
                    }
                    return true;
                }
                catch (Exception)
                {

                    return false;
                }
            }


            public List<Customer> GetAllCustomers()
            {
                try
                {
                    return new DataEntities().Customers.ToList();
                }
                catch (Exception)
                {

                    return null;
                }

            }

            public bool Gym(int tenantid, string status, DateTime date)
            {
                try
                {
                    Gym_record gym = new Gym_record()
                    {
                        TenantId = tenantid,
                        Gym_status = status,
                        Time_and_date = date
                    };
                    db.Gym_record.Add(gym);
                    db.SaveChanges();
                    return true;
                }
                catch (Exception)
                {
                    return false;
                }
            }

            public bool JoinTenants(string address, string city, string state, string mail, long phone)
            {
                try
                {
                    Tenant tenant = new Tenant { TenantAddress = address, TetnantCity = city, TenantState = state, TenantPhone = phone };
                    db.Tenants.Add(tenant);
                    db.SaveChanges();
                    return true;
                }
                catch (Exception)
                {
                    return false;
                }
            }

            public bool problem(int tenantid, string qury, string status)
            {
                try
                {
                Query qry = new Query()
                {
                    QueryId = tenantid,
                        TenantId = tenantid,
                        query1 = qury,
                        service_status = "Notsolved"
                    };
                    db.Queries.Add(qry);
                    db.SaveChanges();
                    return true;
                }
                catch (Exception )
                {
                    return false;
                }
            }


            public bool RegisterCustomer(string mailid, string name, string Password)
            {
                try
                {
                    Customer usr = new Customer
                    {
                        MailId = mailid,
                        Name = name,
                        passwordHash = Password
                    };
                    db.Customers.Add(usr);
                    db.SaveChanges();
                    return true;
                }
                catch (Exception)
                { return false; }

            }

            public bool swimming(int tenantid, string status, DateTime date)
            {
                try
                {
                    Swimming_record swim = new Swimming_record()
                    {
                        TenantId = tenantid,
                        swimming_status = status,
                        Time_and_date = date
                    };
                    db.Swimming_record.Add(swim);
                    db.SaveChanges();
                    return true;
                }
                catch (Exception)
                {
                    return false;
                }
            }
            public bool UpdateCustomer(string loginid, string name, string Password)
            {
                try
                {
                    Customer usr = db.Customers.FirstOrDefault((c) => c.MailId == loginid && c.passwordHash == Password);
                    usr.MailId = loginid.ToString();
                    usr.passwordHash = Password;
                    usr.Name = name;
                    db.SaveChanges();
                    return true;
                }
                catch (Exception)
                {
                    return false;
                }
            }

            public int CustomerLogin(string mailid, string password)
            {
                try
                {
                    Customer usr = db.Customers.FirstOrDefault((u) => u.MailId == mailid && u.passwordHash == password);
                    return usr.UserId;
                }
                catch (Exception)
                {
                    return 0;
                }


            }

            public bool UpdateTenant(int tenantid, string address, string city, string state, string mail, long phone)
            {
                try
                {
                    Tenant tnt = db.Tenants.FirstOrDefault((c) => c.TenantId == tenantid);
                    tnt.TenantAddress = address;
                    tnt.TenantPhone = phone;
                    tnt.TetnantCity = city;
                    tnt.TenantState = state;
                    db.SaveChanges();
                    return true;
                }
                catch (Exception)
                {
                    return false;
                }
            }

            public bool deleteCustomer(string mailid)
            {
                try
                {
                    Customer usr = db.Customers.FirstOrDefault((c) => c.MailId == mailid);
                    db.Customers.Remove(usr);
                    db.SaveChanges();
                    return true;
                }
                catch (Exception)
                {

                    return false;
                }
            }

            public List<Tenant> GetAllTenants()
            {
                try
                {
                    return new DataEntities().Tenants.ToList();
                }
                catch (Exception)
                {
                    return null;
                }
            }
            public bool Deletetenant(string mailId)
            {
                try
                {
                    var dlt = db.Tenants.FirstOrDefault((c) => c.Mail_Id == mailId);
                    db.Tenants.Remove(dlt);
                    db.SaveChanges();
                    return true;
                }
                catch (Exception)
                {
                    return false;
                }
            }
            public List<Allotment> GetAllotments()
            {
                try
                {
                    return new DataEntities().Allotments.ToList();
                }
                catch (Exception)
                {

                    return null;
                }
            }

            public bool deleteAllot(int Allotid)
            {
                try
                {
                    var dlt = db.Allotments.FirstOrDefault((c) => c.RoomNo == Allotid);
                    db.Allotments.Remove(dlt);
                    db.SaveChanges();
                    return true;
                }
                catch (Exception)
                {
                    return false;
                }
            }

            public List<Query> getAllproblems()
            {
                try
                {
                    return new DataEntities().Queries.ToList();
                }
                catch (Exception)
                {

                    return null;
                }
            }

            public bool UpdateQuerytosolve(int id)
            {
                try
                {
                    var query = db.Queries.FirstOrDefault((Q) => Q.QueryId == id);
                    return true;
                }
                catch (Exception)
                {
                    return false;
                }
            }

            public List<Gym_record> getGymrecords()
            {
                try
                {
                    return new DataEntities().Gym_record.ToList();
                }
                catch (Exception)
                {

                    return null;
                }
            }

            public List<Swimming_record> getswimminRecords()
            {
                try
                {
                    return new DataEntities().Swimming_record.ToList();
                }
                catch (Exception)
                {

                    return null;
                }
            }

            public List<FamilyClub> getprogrammeRecords()
            {
                try
                {
                    return new DataEntities().FamilyClubs.ToList();
                }
                catch (Exception)
                {

                    return null;
                }
            }

            public List<Rent> GetAllRents()
            {
                try
                {
                    return new DataEntities().Rents.ToList();
                }
                catch (Exception)
                {

                    return null;
                }
            }

            public bool clearRent(int id)
            {
                try
                {
                    var it = db.Rents.FirstOrDefault((c) => c.RentId == id);
                    it.Paid_status = "Cleared";
                    return true;
                }
                catch (Exception)
                {

                    return false;
                }
            }

        public Customer customerId(string mailId)
        {
           var id =   db.Customers.FirstOrDefault((c) => c.MailId==mailId);
            return id;
        }
    }

    
    public static class DataFactory1
    {
        public static IDataComponent Getcomponent()
            {
                return new DataComponent();
            }
    }
}

