﻿using DataAccessLayer;
using NewApartment;
using System;
using System.Collections.Generic;

namespace BusinessLayer
{
    public interface IBusiness {
        bool RegisterCustomer(Customer customer);
        bool UpdateCustomer(Customer customer);
        int CustomerLogin(Customer customer);
        bool deleteCustomer(Customer customer);
        List<Customer> GetAllCustomers();

        List<Rent> GetAllRents();
        bool clearRent(int id);


        List<Tenant> GetAllTenants();
        bool JoinTenants(Tenant tenant);
        bool UpdateTenant(Tenant tenant);
        bool Deletetenant(Tenant tenant);
        Customer customerId(string mailId);

        List<Allotment> GetAllotments();
        bool Allot(Allotment allot);
        bool deleteAllot(Allotment allot);
        bool Allotupdate(Allotment allot);

        bool problem(Query query);
        List<Query> getAllproblems();
        bool UpdateQuerytosolve(int id);

        List<Gym_record> getGymrecords();
        bool Gym(Gym_record gym);

        List<Swimming_record> getswimminRecords();
        bool swimming(Swimming_record swim);

        List<FamilyClub> getprogrammeRecords();
        bool familyclub(FamilyClub familyClub);
    }
 

    class Business : IBusiness
    {
        IDataComponent db = DataFactory1.Getcomponent();
        public bool Allot(Allotment allot)
        {
            try
            {
                db.Allot(allot.TenantId, allot.Number_of_people, allot.Area_of_Room_in_sqf);
                return true;
            }
            catch (Exception)
            {

                return false;
            }

        }

        public bool Allotupdate(Allotment allot)
        {
            try
            {
                db.Allotupdate(allot.TenantId, allot.Number_of_people, allot.Area_of_Room_in_sqf);
                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }

        public bool clearRent(int id)
        {
            try
            {
                db.clearRent(id);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public int CustomerLogin(Customer customer)
        {

            try
            {
                {
                    if (db.CustomerLogin(customer.MailId, customer.passwordHash) != 0)
                        return db.CustomerLogin(customer.MailId, customer.passwordHash);
                    else
                        return 0;

                }
            }
            catch (Exception)
            {

                return 0;
            }
            
        }

        public bool deleteAllot(Allotment allot)
        {
            try
            {
                db.deleteAllot(allot.TenantId);
                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }

        public bool deleteCustomer(Customer customer)
        {
            try
            {
                db.deleteCustomer(customer.MailId);
               return true;
            }
            catch (Exception)
            {

                return false;
            }
        }

        public bool Deletetenant(Tenant tenant)
        {
            try
            {
                db.Deletetenant(tenant.Mail_Id);
                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }

        public bool familyclub(FamilyClub familyClub)
        {
            try
            {
                db.familyclub(familyClub.RoomNo, familyClub.date_Booked, familyClub.date_Booked);

                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }

        public List<Customer> GetAllCustomers()
        {
            throw new NotImplementedException();
        }

        public List<Allotment> GetAllotments()
        {
            try
            {
               return  db.GetAllotments();
               
            }
            catch (Exception)
            {

                return null;
            }
        }

        public List<Query> getAllproblems()
        {
            try
            {
                return db.getAllproblems();
                
            }
            catch (Exception)
            {

                return null;
            }
        }

        public List<Rent> GetAllRents()
        {
            try
            {
                return db.GetAllRents();
            }
            catch (Exception)
            {

                return null;
            }
        }

        public List<Tenant> GetAllTenants()
        {
            throw new NotImplementedException();
        }

        public List<Gym_record> getGymrecords()
        {
            try
            {

                return db.getGymrecords();
            }
            catch (Exception)
            {

                return null;
            }
        }

        public List<FamilyClub> getprogrammeRecords()
        {
            try
            {
                return db.getprogrammeRecords();
            }
            catch (Exception)
            {

                return null;
            }
        }

        public List<Swimming_record> getswimminRecords()
        {
            try
            {
                return  db.getswimminRecords();
                
            }
            catch (Exception)
            {

                return null;
            }
        }

        public bool Gym(Gym_record gym)
        {
            try
            {
               db.Gym(gym.TenantId,  gym.Gym_status,gym.Time_and_date);
                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }

        public bool JoinTenants(Tenant tenant)
        {
            try
            {
                db.JoinTenants(tenant.TenantAddress, tenant.TetnantCity, tenant.TenantState, tenant.Mail_Id, tenant.TenantPhone);
                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }

        public bool problem(Query query)
        {
            try
            {
                db.problem(query.TenantId, query.query1, query.service_status);
                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }
        public bool swimming(Swimming_record swim)
        {
            try
            {
                db.swimming(swim.TenantId, swim.swimming_status, swim.Time_and_date);
                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }
        public bool RegisterCustomer(Customer customer)
        {
            try
            {
                db.RegisterCustomer(customer.MailId,customer.Name,customer.passwordHash);
                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }

       

        public bool UpdateCustomer(Customer customer)
        {
            try
            {
                db.UpdateCustomer(customer.MailId, customer.Name, customer.passwordHash);
                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }

        public bool UpdateQuerytosolve(int id)
        {
            try
            {
                db.UpdateQuerytosolve(id);
                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }

        public bool UpdateTenant(Tenant tenant)
        {
            try
            {
                db.UpdateTenant(tenant.UserId,tenant.TenantAddress, tenant.TetnantCity, tenant.TenantState, tenant.Mail_Id, tenant.TenantPhone);
                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }

        public Customer customerId(string mailId)
        {
           return db.customerId(mailId);
        }
    }
    public static class DataFactory
    {
        public static IBusiness getComponent()
        {
            return new Business();
        }
    }
}

