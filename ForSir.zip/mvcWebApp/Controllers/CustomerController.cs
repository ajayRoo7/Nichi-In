﻿using System;
using System.Web.Mvc;
using mvcWebApp.DataReference;
using static System.Net.WebRequestMethods;

namespace mvcWebApp.Controllers
{
    public class CustomerController : Controller
    {
        DataserviceClient proxy = new DataserviceClient();

        // GET: Customer
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult RegisterUser()
        {
            return View(new Customer());
        }
        [HttpPost]
        public ActionResult RegisterUser( Customer customer)
        {
            proxy.RegisterCustomer(customer);
            ViewBag.message = "Regestered Succesuly";
            return View("Index");
        }




        public ActionResult Customerlogin()
        {
            return View(new Customer());
        }
        [HttpPost]
        public ActionResult Customerlogin(Customer customer)
        {
            int check = proxy.CustomerLogin(customer);

            Session["CustomerId"] = proxy.customerId(customer.MailId);
            if (check == 0)
            {
                ViewBag.Message = "Invalid Credentials";
            }
            return View("JoinTenant");
        }


        public ActionResult Adminlogin()
        {
            return View(new Customer());
        }
        [HttpPost]
        public ActionResult Adminlogin(Customer customer)
        {
            int check = proxy.CustomerLogin(customer);
            
            Session["CustomerId"] = proxy.customerId(customer.MailId);
            if (check==0)
            {
                ViewBag.Message = "Invalid Credentials";
            }
            return RedirectToAction("Index1","Admin"); 
        }



        public ActionResult Problem()
        {
            return View(new Query());

        }
        [HttpPost]
        public ActionResult Problem(FormCollection form)
        {
          bool check=  proxy.problem(new Query { query1 = form["query"], TenantId= Convert.ToInt32(Session["CustomerId"])});
            if (check != true)
            {
                ViewBag.Message = "Could not be sent";
            }
            return View("UserOperations");
        }




        public  ActionResult JoinTenant()
        {
            return View(new Tenant1());
        }
        [HttpPost]
        public ActionResult JoinTenant(Tenant1 tenant)
        {
            tenant.UserId = proxy.customerId(tenant.Mail_Id).UserId;
            proxy.JoinTenants(tenant);
            return View("Index");
        }


        public ActionResult FamilyClub()
        {
            return View(new FamilyClub());
        }
        [HttpPost]
        public ActionResult FamilyClub(FamilyClub1 family)
        {
            bool check = proxy.familyclub(family);
            if (check != true)
            {
                ViewBag.Message = "Could not Book";
            }
            return View();
        }



        public ActionResult gym()
        {
            return View(new Gym_record());
        }
        [HttpPost]
        public ActionResult gym(Gym_record gym_Record)

        {
           bool check =  proxy.Gym(gym_Record);
            if (check != true)
            {
                ViewBag.Message = "Gym has not Registered";
            }
            return View();
        }
    }
}