﻿using mvcWebApp.DataReference;
using System.Web.Mvc;

namespace mvcWebApp.Controllers
{
    public class AdminController : Controller
    {
        // GET: Admin
        DataserviceClient proxy = new DataserviceClient();
        public ActionResult Index1()
        {
            return View();
        }
        public ActionResult Customers()
        {
            return View(new Customer());
        }
        [HttpGet]
        public ActionResult Customers(Customer customer)
        {
            proxy.GetAllCustomers();
            return View();
        }

    }
}