﻿using BALComponent;
using System.Runtime.Serialization;
using System.ServiceModel;

namespace ApartmentWcfDll
{
    [ServiceContract]
    public interface IUserComponent
    {
        [OperationContract]
        void RegisterUser(User usr);
    }
    [DataContract]
    public class User
    {
        [DataMember] public int UserId { get; set; }
        [DataMember] public string MailId { get; set; }
        [DataMember] public string Name { get; set; }
        [DataMember] public string passwordHash { get; set; }

    }
    class UserService : IUserComponent
    {
        public void RegisterUser(User usr)
        {
            var com = Datafactory.getComponent();
            com.RegisterUser(new ApartmemtManagement.User { UserId = usr.UserId, MailId = usr.MailId, Name = usr.Name, passwordHash = usr.passwordHash });
        }
    }
}
