﻿using System;

namespace RecapDemo
{
    class Myconsole
    {
        public static string Getstring(string question)
        {
            Console.WriteLine(question);
            return Console.ReadLine();
        }
        public static double Getdouble(string question)
        {
            string answer = Getstring(question);
            return double.Parse(answer);
        }
        public static int Getnumber(string question)
        {
            string answer = Getstring(question);
            return int.Parse(answer);
        }
        public static DateTime getDate(string question)
        {
            Console.WriteLine(question);
            DateTime dt = DateTime.Parse(Console.ReadLine());
            return dt;
        }


        public static void ClearScreen()
        {
            Console.WriteLine("prss any key to clear");
            Console.ReadKey();
            Console.Clear();
        }
    }
}
