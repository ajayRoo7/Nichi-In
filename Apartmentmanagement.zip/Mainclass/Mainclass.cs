﻿using ApartmemtManagement;
using BALComponent;
using RecapDemo;
using System;

namespace Mainclass
{
    class Mainclass
    {
        static void Main(string[] args)
        {
            IBALcomponenet db = Datafactory.getComponent();
            Console.WriteLine("Welcome to Apartment Management System");
            int key = Myconsole.Getnumber("press 1 to login as admin\npress 2 to login as user\npress 3 to register");
            switch (key)
            {
                case 2:
                    string mailid = Myconsole.Getstring("enter user MailId to login as User");
                    string name = Myconsole.Getstring("Enter your full name with Initials");
                    String pwd = Myconsole.Getstring("Enter password");
                    User usr = new User
                    {
                        MailId = mailid,
                        Name = name,
                        passwordHash = pwd
                    };
                    if (db.UserLogin(usr) != null)
                    {
                        Console.WriteLine("Invalid Credentials");
                    }
                    else
                    {
                        Console.WriteLine("user Features");
                    }


                    break;
                case 1:
                    string umailid = Myconsole.Getstring("enter user Your mailId to login as Admin");
                    string Uname = Myconsole.Getstring("Enter yoout full name with Initials");
                    String Upwd = Myconsole.Getstring("Enter password");
                    if (umailid != "" || Uname != "deekshit" || Upwd != "990026")
                    {
                        Console.WriteLine("Invalid Credentials");
                    }
                    else
                    {
                        Console.WriteLine("Admin tasks");
                    }
                    break;
                case 3:
                    string Mailid = Myconsole.Getstring("enter user MailId to login as Admin");
                    string username = Myconsole.Getstring("Enter yoout full name with Initials");
                    String userpwd = Myconsole.Getstring("Enter password");
                    User regusr = new User
                    {
                        MailId = Mailid,
                        Name = username,
                        passwordHash = userpwd
                    };
                    db.RegisterUser(regusr);
                    break;
                default:
                    Console.WriteLine("select a valid option");
                    break;
            }
        }
    }
}
