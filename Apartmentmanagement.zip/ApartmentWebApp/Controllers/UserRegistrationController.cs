﻿using ApartmentWebApp.UserServiceReference;
using System.Web.Mvc;

namespace ApartmentWebApp.Controllers
{
    public class UserRegistrationController : Controller
    {
        // GET: UserRegistration
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult UserRegister()
        {
            return View(new User());
        }
        [HttpPost]
        public ActionResult UserRegister(User user)
        {
            var com = new UserComponentClient();
            com.RegisterUser(user);
            return RedirectToAction("Index");
        }
    }
}