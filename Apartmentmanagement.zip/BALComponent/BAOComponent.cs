﻿using ApartmemtManagement;
using DAL;
using System.Data;

namespace BALComponent
{
    public interface IBALcomponenet
    {
        void RegisterUser(User usr);
        User UserLogin(User usr);
        void UpdateUser(User usr);
        void delete(User usr);
        void JoinTenants(Tenant tnt);
        void UpdateTenant(Tenant tnt);
        void Allot(Allotment allot);
        void problem(Query qry);
        void Gym(Gym_record gym);
        void swimming(Swimming_record swim);
        void Allotupdate(Allotment allot);
        DataTable GetAllUsers();
    }
    public class BAOcomponent : IBALcomponenet
    {
        IDALcomponent obj = DataFactory.Getcomponent();
        public void Allot(Allotment allot)
        {
            obj.Allot(allot.TenantId, allot.Number_of_people, allot.Area_of_Room_in_sqf);
        }

        public void Allotupdate(Allotment allot)
        {
            obj.Allotupdate(allot.TenantId, allot.Number_of_people, allot.Area_of_Room_in_sqf);
        }

        public void delete(User usr)
        {
            obj.delete(usr.MailId, usr.passwordHash);
        }

        public DataTable GetAllUsers()
        {
            return obj.GetAllUsers();
        }

        public void Gym(Gym_record gym)
        {
            obj.Gym(gym.TenantId, gym.Gym_status, gym.Time_and_date);
        }

        public void JoinTenants(Tenant tnt)
        {
            obj.JoinTenants(tnt.TenantAddress, tnt.TetnantCity, tnt.TenantState, tnt.TenantPhone.ToString(), tnt.UserId);
        }

        public void problem(Query qry)
        {
            obj.problem(qry.TenantId, qry.query1, qry.service_status);
        }

        public void RegisterUser(User usr)
        {
            obj.RegisterUser(usr.MailId, usr.Name, usr.passwordHash);
        }

        public void swimming(Swimming_record swim)
        {
            obj.swimming(swim.TenantId, swim.swimming_status, swim.Time_and_date);
        }

        public void UpdateTenant(Tenant tnt)
        {
            obj.UpdateTenant(tnt.TenantId, tnt.TenantAddress, tnt.TetnantCity, tnt.TenantState, tnt.TenantPhone.ToString(), tnt.UserId);
        }

        public void UpdateUser(User usr)
        {
            obj.UpdateUser(usr.MailId, usr.Name, usr.passwordHash);
        }

        public User UserLogin(User usr)
        {
            User user = obj.UserLogin(usr.MailId, usr.passwordHash);

            return user;
        }
    }
    public static class Datafactory
    {
        public static IBALcomponenet getComponent()
        {
            return new BAOcomponent();
        }
    }
}
