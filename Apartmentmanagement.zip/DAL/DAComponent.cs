﻿using ApartmemtManagement;
using System;
using System.Data;
using System.Linq;

namespace DAL
{
    public interface IDALcomponent
    {
        void RegisterUser(string mailid, string name, string Password);
        void UpdateUser(string mailid, string name, string Password);
        void delete(string mailid, string Password);
        void JoinTenants(string address, string city, string state, string mail, long phone);
        void UpdateTenant(int userid, string address, string city, string state, string mail, long phone);
        void Allot(int tenantid, int people, int area);
        void problem(int tenantid, string query, string status);
        void Gym(int tenantid, string status, DateTime date);
        void swimming(int tenantid, string status, DateTime date);
        void Allotupdate(int tenantid, int people, int area);
        DataTable GetAllUsers();
        User UserLogin(string mailid, string password);
        void familyclub(int roomno, DateTime bookingdate, DateTime bookinglast);
    }

    public class DAComponent : IDALcomponent
    {
        static ApartEntities db = new ApartEntities();

        public void Allot(int tenantid, int people, int area)
        {
            Allotment allot = new Allotment()
            {
                TenantId = tenantid,
                Number_of_people = people,
                Area_of_Room_in_sqf = area
            };
            db.Allotments.Add(allot);
            db.SaveChanges();
        }

        public void Allotupdate(int tenantid, int people, int area)
        {
            Allotment allot = db.Allotments.FirstOrDefault((c) => c.TenantId == tenantid);
            allot.Number_of_people = people;
            allot.Area_of_Room_in_sqf = area;
            db.SaveChanges();
        }

        public void delete(string mailid, string Password)
        {
            User usr = db.Users.FirstOrDefault((c) => c.MailId == mailid && c.passwordHash == Password);
            db.Users.Remove(usr);
            db.SaveChanges();
        }

        public void familyclub(int roomno, DateTime bookingdate, DateTime bookinglast)
        {
            FamilyClub familyClub = new FamilyClub()
            {
                RoomNo = roomno,
                date_Booked = bookingdate,
                date_of_ending = bookinglast
            };
            db.FamilyClubs.Add(familyClub);
        }

        public DataTable GetAllUsers()
        {
            DataTable table = new DataTable();
            foreach (User item in db.Users)
            {
                table.Rows.Add(item);
            }
            return table;
        }

        public void Gym(int tenantid, string status, DateTime date)
        {
            Gym_record gym = new Gym_record()
            {
                TenantId = tenantid,
                Gym_status = status,
                Time_and_date = date
            };
            db.Gym_record.Add(gym);
            db.SaveChanges();
        }

        public void JoinTenants(string address, string city, string state, string mail, long phone)
        {
            Tenant tenant = new Tenant { TenantAddress = address, TetnantCity = city, TenantState = state, TenantPhone = phone };
            db.Tenants.Add(tenant);
            db.SaveChanges();
        }

        public void problem(int tenantid, string qury, string status)
        {
            Query qry = new Query()
            {
                TenantId = tenantid,
                query1 = qury,
                service_status = status
            };
            db.Queries.Add(qry);
            db.SaveChanges();
        }


        public void RegisterUser(string mailid, string name, string Password)
        {


            User usr = new User
            {
                MailId = mailid,
                Name = name,
                passwordHash = Password
            };
            db.Users.Add(usr);
            db.SaveChanges();

        }

        public void swimming(int tenantid, string status, DateTime date)
        {
            Swimming_record swim = new Swimming_record()
            {
                TenantId = tenantid,
                swimming_status = status,
                Time_and_date = date
            };
            db.Swimming_record.Add(swim);
            db.SaveChanges();
        }

        public void UpdateTenant(int tenantId, string address, string city, string state, long phone)
        {
            Tenant tnt = db.Tenants.FirstOrDefault((c) => c.TenantId == tenantId);
            tnt.TenantAddress = address;
            tnt.TenantPhone = phone;
            tnt.TetnantCity = city;
            tnt.TenantState = state;
            db.SaveChanges();

        }

        public void UpdateTenant(int userid, string address, string city, string state, string mail, long phone)
        {
            throw new NotImplementedException();
        }

        public void UpdateUser(string loginid, string name, string Password)
        {
            User usr = db.Users.FirstOrDefault((c) => c.MailId == loginid && c.passwordHash == Password);
            usr.MailId = loginid.ToString();
            usr.passwordHash = Password;
            usr.Name = name;
            db.SaveChanges();
        }

        public User UserLogin(string mailid, string password)
        {
            User usr = db.Users.FirstOrDefault((u) => u.MailId == mailid && u.passwordHash == password);
            return usr;
        }
    }
    public static class DataFactory
    {
        public static IDALcomponent Getcomponent()
        {
            return new DAComponent();
        }
    }
}
