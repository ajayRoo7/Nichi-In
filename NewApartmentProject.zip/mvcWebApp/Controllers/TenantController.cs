﻿using System.Web.Mvc;
using mvcWebApp.DataReference;
using System;

namespace mvcWebApp.Controllers
{
    public class TenantController : Controller
    {
        // GET: Tenant
        DataserviceClient proxy = new DataserviceClient();
        public ActionResult JoinTenant()
        {
            return View(new NewWcfservice.Tenant());
        }
        [HttpPost]
        public ActionResult JoinTenant(NewWcfservice.Tenant tenant)
        {
            proxy.JoinTenants(new NewWcfservice.Tenant { Mail_Id = tenant.Mail_Id, UserId = Convert.ToInt32(Session["CustomerId"]), TenantAddress=tenant.TenantAddress, TenantId=tenant.TenantId, TenantPhone=tenant.TenantPhone,TenantState=tenant.TenantState, TetnantCity=tenant.TetnantCity });
            return View();
        }

    }
}