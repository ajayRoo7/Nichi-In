﻿using mvcWebApp.DataReference;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace mvcWebApp.Controllers
{
    public class CustomerOperationController : Controller
    {
        // GET: CustomerOperation
        DataserviceClient proxy = new DataserviceClient();



        public ActionResult TenantProblems()
        {
            return View(new Query());
        }
        [HttpPost]
        public ActionResult TenantProblems(Query query)
        {
           int tenantid= proxy.getId(Convert.ToInt32(Session["CustomerId"]));
            proxy.problem(new NewWcfservice.Query { TenantId = tenantid, query1 = query.query1 });
            return RedirectToAction("TenantProblems");
        }

        public ActionResult Swimrecord()
        {
            return View(new Swimming_record());
        }


        [HttpPost]
        public ActionResult Swimrecord(Swimming_record swim)
        {
            int tenantid = proxy.getId(Convert.ToInt32(Session["CustomerId"]));
              proxy.swimming(new NewWcfservice.Swimming_record { TenantId = tenantid, swimming_status="used", Time_and_date = DateTime.Now});
            return RedirectToAction("TenantProblems");
        }

        public ActionResult Gymrecord()
        {
            return View(new Gym_record());
        }
        [HttpPost]
        public ActionResult gymrecord(Gym_record gym)
        {
            int tenantid = proxy.getId(Convert.ToInt32(Session["CustomerId"]));
            proxy.Gym(new NewWcfservice.Gym_record { TenantId = tenantid, Gym_status = "used", Time_and_date = DateTime.Now });
            return RedirectToAction("Tenantproblems");
        }

        public ActionResult Familylub()
        {
            return View(new FamilyClub());
        }
        [HttpPost]
        public ActionResult FamilyClub(FamilyClub club)
        {
            try
            {

                int tenantid = proxy.getId(Convert.ToInt32(Session["CustomerId"]));
                int roono = proxy.getroono(tenantid);

             bool check  = proxy.familyclub(new NewWcfservice.FamilyClub { RoomNo = roono, date_Booked = club.date_Booked, date_of_ending = club.date_of_ending });
                ViewBag["status"] = check;
                return RedirectToAction("Tenantproblems");

            }
            catch (Exception)
            {
                return null;
            }
        }
    }

}