﻿using mvcWebApp.DataReference;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;

namespace mvcWebApp.Controllers
{
    public class AdminController : Controller
    {
        // GET: Admin
        DataserviceClient proxy = new DataserviceClient();
        public ActionResult Index1()
        {
            return View();
        }
        public ActionResult Customers()
        {
            return View(new Customer());
        }
        [HttpGet]
        public ActionResult Customers(Customer customer)
        {
            List<Customer> list = proxy.GetAllCustomers().ToList();
            return View(list);
        }


        public ActionResult getTenants()
        {
            return View(new Tenant());
        }
        [HttpGet]
        public ActionResult getTenants(Customer customer)
        {
            List<Tenant> list = proxy.GetAllTenants().ToList();
            return View(list);
        }
        public ActionResult AddAllot()
        {
            return View(new Allotment());
        }
        [HttpPost]
        public ActionResult AddAllot(Allotment allot)
        {
            int A = allot.Area_of_Room_in_sqf;
            int no = allot.Number_of_people;
            int id = allot.TenantId;
            int Rono = allot.RoomNo;
            proxy.Allot(A, no, id, Rono);                      
            return View();
        }
        [HttpGet]
        public ActionResult ClearRent()
        {       
            List<Rent> list = proxy.GetAllRents().ToList();
            return View(list);
        }
        public ActionResult Edit(int id)
        {
             proxy.clearRent(id);
            return View("Index1");
        }


        [HttpGet]
        public ActionResult Queries()
        {
            List<Query> list = proxy.getAllproblems().ToList();
            return View(list);
        }
        public ActionResult Solved(int id)
        {
            proxy.UpdateQuerytosolve(id);
            return View("Index1");
        }



        [HttpGet]
        public ActionResult Allotments()
        {
            List<Allotment> list = proxy.GetAllotments().ToList();
            return View(list);
        }
        public ActionResult AllotEdit(int id)
        {
            Allotment alot = new Allotment();
            alot.RoomNo = id;
            return View(alot);
        }
        [HttpPut]
        public ActionResult AllotEdit(Allotment allot)
        {
            proxy.Allotupdate(new NewWcfservice.Allotment  { Area_of_Room_in_sqf=allot.Area_of_Room_in_sqf, RoomNo=allot.RoomNo, Number_of_people=allot.Number_of_people, TenantId=allot.TenantId});
            return View("Index1");
        }



    }
}