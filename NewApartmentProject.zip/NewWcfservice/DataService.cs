﻿using BusinessLayer;
using NewApartment;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;

namespace NewWcfservice
{
    [ServiceContract]
    interface IDataservice
    {
        [OperationContract]
        int getroono(int id);
        [OperationContract]
        void RegisterCustomer(Customer usr);
        [OperationContract]
        int getId(int id);
        [OperationContract]
        int CustomerLogin(Customer usr);
        [OperationContract]
        bool EditProfile(Customer usr);
        [OperationContract]
        bool problem(Query qry);
        [OperationContract]
        Customer customerId(string mailId);
        [OperationContract]
        bool Gym(Gym_record gym);
        [OperationContract]
        void swimming(Swimming_record swim);
        [OperationContract]
       
        bool UpdateCustomer(Customer customer);
        [OperationContract]
        bool deleteCustomer(Customer customer);
        [OperationContract]
        List<NewApartment.Customer> GetAllCustomers();
        [OperationContract]

        List<Rent> GetAllRents();
        [OperationContract]
        bool clearRent(int id);
        [OperationContract]


        List<NewApartment.Tenant> GetAllTenants();
        [OperationContract]
        bool JoinTenants(Tenant tenant);
        [OperationContract]
        bool UpdateTenant(Tenant tenant);
        [OperationContract]
        bool Deletetenant(Tenant tenant);
        [OperationContract]

        List<NewApartment.Allotment> GetAllotments();
        [OperationContract]
        bool Allot(int Area, int no, int id, int roomno);
        [OperationContract]
        bool deleteAllot(Allotment allot);
        [OperationContract]
        bool Allotupdate(Allotment allot);
        
        [OperationContract]
        List<NewApartment.Query> getAllproblems();
        [OperationContract]
        bool UpdateQuerytosolve(int id);
        [OperationContract]
        List<NewApartment.Gym_record> getGymrecords();
        
     
        [OperationContract]
        List<NewApartment.Swimming_record> getswimminRecords();
        [OperationContract]
      
        List<NewApartment.FamilyClub> getprogrammeRecords();
        [OperationContract]
        bool familyclub(FamilyClub familyClub);
    }
    [DataContract]
    public class Tenant
    {
        [DataMember] public int TenantId { get; set; }
        [DataMember] public int UserId { get; set; }
        [DataMember] public string TenantAddress { get; set; }
        [DataMember] public string TetnantCity { get; set; }
        [DataMember] public string TenantState { get; set; }
        [DataMember] public long TenantPhone { get; set; }
        [DataMember] public string Mail_Id { get; set; }
    }
    [DataContract]
    public class Allotment
    {
        public int RoomNo { get; set; }
        public int TenantId { get; set; }
        public int Number_of_people { get; set; }
        public int Area_of_Room_in_sqf { get; set; }
    }
    [DataContract]
    public class FamilyClub
    {
       [DataMember] public int programmeId { get; set; }
        [DataMember] public int RoomNo { get; set; }
        [DataMember] public System.DateTime date_Booked { get; set; }
        [DataMember]  public System.DateTime date_of_ending { get; set; }
    }
    [DataContract]
    public class rent
    {
        [DataMember] public int RentId { get; set; }
        [DataMember] public int RoomNo { get; set; }
        [DataMember] public Nullable<decimal> Due_Amount { get; set; }
        [DataMember] public string Paid_status { get; set; }
    }
    [DataContract]
    public class Swimming_record
    {
        [DataMember] public int TenantId { get; set; }
        [DataMember] public string swimming_status { get; set; }
        [DataMember] public System.DateTime Time_and_date { get; set; }
    }
    [DataContract]
    public class Gym_record
    {
        [DataMember] public int TenantId { get; set; }
        [DataMember] public string Gym_status { get; set; }
        [DataMember] public System.DateTime Time_and_date { get; set; }
    }
    [DataContract]
    public class Query
    { 
        [DataMember] public int TenantId { get; set; }
        [DataMember] public string query1 { get; set; }
        [DataMember] public string service_status { get; set; }
    }

    [DataContract]
    public class Customer
    {
        [DataMember] public int UserId { get; set; }
        [DataMember] public string MailId { get; set; }
        [DataMember] public string Name { get; set; }
        [DataMember] public string passwordHash { get; set; }

    }
    class DataService : IDataservice

    {
        IBusiness com = DataFactory.getComponent();
        public bool  Gym(Gym_record gym)
        {
            try
            {
                com.Gym(new NewApartment.Gym_record { TenantId = gym.TenantId, Time_and_date = gym.Time_and_date });
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool  problem(Query qry)
        {
            try
            {
                com.problem(new NewApartment.Query { TenantId = qry.TenantId, query1 = qry.query1 });
                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }

        public void swimming(Swimming_record swim)
        {
            com.swimming(new NewApartment.Swimming_record { TenantId = swim.TenantId, Time_and_date = swim.Time_and_date });
        }
        public bool EditProfile(Customer usr)
        {
            try
            {
                com.UpdateCustomer(new NewApartment.Customer { UserId = usr.UserId, MailId = usr.MailId, Name = usr.Name, passwordHash = usr.passwordHash });
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public void RegisterCustomer(Customer usr)
        {

            com.RegisterCustomer(new NewApartment.Customer { UserId = usr.UserId, MailId = usr.MailId, Name = usr.Name, passwordHash = usr.passwordHash });
        }
        public int CustomerLogin(Customer usr)
        {
            try
            {
               int id =  com.CustomerLogin(new NewApartment.Customer { MailId = usr.MailId, passwordHash = usr.passwordHash });
                return id;
            }
            catch (Exception)
            {
                return 0;
            }
        }

        public bool UpdateCustomer(Customer customer)
        {
            try
            {
                com.UpdateCustomer(new NewApartment.Customer { MailId = customer.MailId, Name = customer.Name, passwordHash = customer.passwordHash });
                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }

        public bool deleteCustomer(Customer usr)
        {
            try
            {
                com.deleteCustomer(new NewApartment.Customer { UserId = usr.UserId, MailId = usr.MailId, Name = usr.Name, passwordHash = usr.passwordHash });
                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }

        public List<NewApartment.Customer> GetAllCustomers()
        {
            try
            {
                return com.GetAllCustomers();
            }
            catch (Exception)
            {

                return null;
            }
        }

        public List<Rent> GetAllRents()
        {
            try
            {
                return com.GetAllRents();
            }
            catch (Exception)
            {

                return null;
            }
        }

        public bool clearRent(int id)
        {
            try
            {
                com.clearRent(id);
                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }

        public List<NewApartment.Tenant> GetAllTenants()
        {
            try
            {
                return com.GetAllTenants();
                
            }
            catch (Exception)
            {

                return null;
            }
        }

        public bool JoinTenants(Tenant tenant)
        {
            try
            {
                com.JoinTenants(new NewApartment.Tenant { Mail_Id = tenant.Mail_Id, TenantAddress = tenant.TenantAddress, TenantId = tenant.TenantId, TenantPhone = tenant.TenantPhone, TenantState = tenant.TenantState,  TetnantCity = tenant.TetnantCity,UserId = tenant.UserId});
                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }

        public bool UpdateTenant(Tenant tenant)
        {
            try
            {
                com.UpdateTenant(new NewApartment.Tenant { Mail_Id = tenant.Mail_Id, TenantAddress = tenant.TenantAddress, TenantId = tenant.TenantId, TenantPhone=tenant.TenantPhone, TenantState=tenant.TenantState, });

                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }
        
        public bool Deletetenant(Tenant tenant)
        {
            try
            {

                com.Deletetenant(new NewApartment.Tenant { Mail_Id = tenant.Mail_Id, TenantAddress = tenant.TenantAddress, TenantId = tenant.TenantId, TenantPhone = tenant.TenantPhone, TenantState = tenant.TenantState, });
                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }

        public bool Allot(int Area,int no,int id,int roomno)
        {
            try
            {
                com.Allot( new NewApartment.Allotment{ RoomNo=roomno, TenantId=id, Number_of_people=no, Area_of_Room_in_sqf=Area});
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool deleteAllot(Allotment allot)
        {
            try
            {

                com.deleteAllot(new NewApartment.Allotment { RoomNo = allot.RoomNo, TenantId = allot.TenantId, Number_of_people = allot.Number_of_people, Area_of_Room_in_sqf = allot.Area_of_Room_in_sqf });
                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }

        public bool Allotupdate(Allotment allot)
        {

            try
            {
                com.Allotupdate(new NewApartment.Allotment { RoomNo = allot.RoomNo, TenantId = allot.TenantId, Number_of_people = allot.Number_of_people, Area_of_Room_in_sqf = allot.Area_of_Room_in_sqf });
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public List<NewApartment.Query> getAllproblems()
        {
            try
            {
                return com.getAllproblems();
            }
            catch (Exception)
            {

                return null;
            }
        }

        public bool UpdateQuerytosolve(int id)
        {
            try
            {
                com.UpdateQuerytosolve(id);
                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }

        public List<NewApartment.Gym_record> getGymrecords()
        {
           return  com.getGymrecords();
        }

        public List<NewApartment.Swimming_record> getswimminRecords()
        {
            try
            {
                return com.getswimminRecords();
            }
            catch (Exception)
            {

                return null ;
            }
        }

        public List<NewApartment.FamilyClub> getprogrammeRecords()
        {
            try
            {
               return com.getprogrammeRecords();
            }
            catch (Exception)
            {

                return null;
            }
        }

        public bool familyclub(FamilyClub familyClub)
        {
            try
            {
                com.familyclub(new NewApartment.FamilyClub { programmeId = familyClub.programmeId, RoomNo = familyClub.RoomNo, date_Booked = familyClub.date_Booked, date_of_ending = familyClub.date_of_ending });
                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }

        public List<NewApartment.Allotment> GetAllotments()
        {
            try
            {
                return com.GetAllotments();
            }
            catch (Exception)
            {

                return null;
            }
        }

        public Customer customerId(string mailId)
        {
           NewApartment.Customer temp = com.customerId(mailId);
            return new Customer { MailId = temp.MailId, Name=temp.Name, UserId=temp.UserId };
        }

        public int getId(int id)
        {
            return com.GetId(id);
        }

        public int getroono(int id)
        {
            return com.getroono(id);
        }
    }
}
