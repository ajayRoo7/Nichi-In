﻿using ApartmentEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;

namespace ApartmentWebApplication.Controllers
{
    public class AllotmentController : Controller
    {
        // GET: Allotment
        public ActionResult Index()
        {
            return View();
        }
    }
 }
