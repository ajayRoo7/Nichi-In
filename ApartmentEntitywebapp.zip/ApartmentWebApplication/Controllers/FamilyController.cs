﻿using ApartmentEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;

namespace ApartmentWebApplication.Controllers
{
    public class FamilyController : Controller
    {
        // GET: Family
        public ActionResult Families()
        {
            IEnumerable<FamilyClub> families = null;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:64189/api/");
                //HTTP GET
                var responseTask = client.GetAsync("Family");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<IList<FamilyClub>>();
                    readTask.Wait();

                    families = readTask.Result;
                }
                else //web api sent error response 
                {
                    //log response status here..

                    families = Enumerable.Empty<FamilyClub>();

                    ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                }
            }
            return View(families);
        }
    }
}