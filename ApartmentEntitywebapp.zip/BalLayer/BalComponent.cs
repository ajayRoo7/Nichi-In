﻿using ApartmentEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BalLayer
{
    interface IbalComponent
    {
        public interface IBALComponenet
        {
            void RegisterUser(User usr);
            void UserLogin(User usr);
            void UpdateUser(User usr);
            void delete(string mailid);
            void JoinTenants(Tenant tnt);
            void UpdateTenant(Tenant tnt);
            void Allot(Allotment allot);
            void problem(Query qry);
            void Gym(Gym_record gym);
            void swimming(Swimming_record swim);
            void Allotupdate(Allotment allot);
            List<Customer> GetAllUsers();
        }
    }
    public class BalComponent
    {
    }
}
