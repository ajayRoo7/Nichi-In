﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ApartmentWebApplication.Models
{
    public class Rent
    {
        public int RentId { get; set; }
        public int RoomNo { get; set; }
        public Nullable<decimal> Due_Amount { get; set; }
        public string Paid_status { get; set; }
    }
}