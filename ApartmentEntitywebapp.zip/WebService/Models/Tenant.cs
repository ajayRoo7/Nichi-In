﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ApartmentWebApplication.Models
{
    public class Tenant
    {
        public int TenantId { get; set; }
        public int UserId { get; set; }
        public string TenantAddress { get; set; }
        public string TetnantCity { get; set; }
        public string TenantState { get; set; }
        public long TenantPhone { get; set; }
        public string Mail_Id { get; set; }
    }
}