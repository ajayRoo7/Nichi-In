﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ApartmentWebApplication.Models
{
    public class Gym_record
    {
        public int TenantId { get; set; }
        public string Gym_status { get; set; }
        public System.DateTime Time_and_date { get; set; }
        public int RecordId { get; set; }
    }
}