﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ApartmentWebApplication.Models
{
    public class Allotment
    {
        public int RoomNo { get; set; }
        public int TenantId { get; set; }
        public int Number_of_people { get; set; }
        public int Area_of_Room_in_sqf { get; set; }
    }
}