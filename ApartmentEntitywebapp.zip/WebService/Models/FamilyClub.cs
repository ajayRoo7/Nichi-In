﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ApartmentWebApplication.Models
{
    public class FamilyClub
    {
        public int programmeId { get; set; }
        public int RoomNo { get; set; }
        public System.DateTime date_Booked { get; set; }
        public System.DateTime date_of_ending { get; set; }
    }
}