﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ApartmentWebApplication.Models
{
    public class Customer
    {
        public int UserId { get; set; }
        public string MailId { get; set; }
        public string Name { get; set; }
        public string passwordHash { get; set; }
    }
}