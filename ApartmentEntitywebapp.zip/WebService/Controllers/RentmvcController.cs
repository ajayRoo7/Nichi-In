﻿using ApartmentEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ApartmentWebApplication.Controllers
{
    public class RentController : ApiController
    {
        DataComponent context = DataFactory.Getcomponent();
        public List<Rent> GetAllrents()
        {
            try
            {
                var data = context.GetAllRents();
                var allots = data.Select((c) => new Rent { Due_Amount = c.Due_Amount, Paid_status = c.Paid_status, RentId = c.RentId, RoomNo = c.RoomNo }).ToList();
                return allots;
            }
            catch (Exception)
            {
                return null;
            }
        }
        public bool Clearrent(int id)
        {
            try
            {
                context.clearRent(id);
                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }

    }
}
