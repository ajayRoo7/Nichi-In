﻿using ApartmentEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;


namespace ApartmentWebApplication.Controllers
{
    //    {List<Tenant> GetAllTenants();
    //    bool JoinTenants(string address, string city, string state, string mail, long phone);
    //    bool UpdateTenant(int Customerid, string address, string city, string state, string mail, long phone);
    //    bool Deletetenant(string mailId);
    //}
    public class TenantsController : ApiController
    {
        DataComponent context = DataFactory.Getcomponent();
        [HttpGet]
        public List<Tenant> GetAllTenants()
        {
            var data = context.GetAllTenants();
            var allots = data.Select((c) => new Tenant { Mail_Id = c.Mail_Id, TenantAddress = c.TenantAddress, TenantId = c.TenantId, TenantPhone = c.TenantPhone, TenantState = c.TenantState, TetnantCity = c.TetnantCity, UserId = c.UserId }).ToList();

            return allots;
        }
        [HttpPost]
        public bool JoinTenants(Tenant tnt)
        {
            try
            {
                context.JoinTenants(tnt.TenantAddress, tnt.TetnantCity, tnt.TenantState, tnt.Mail_Id, tnt.TenantPhone);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        [HttpPut]
        public bool UpdateTenant(Tenant tnt)
        {
            try
            {
                context.UpdateTenant(tnt.UserId, tnt.TenantAddress, tnt.TetnantCity, tnt.Mail_Id, tnt.TenantState, tnt.TenantPhone);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        [HttpDelete]
        public bool Deletetenant(string mailId)
        {
            try
            {
                context.Deletetenant(mailId);
                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }
    }
}

