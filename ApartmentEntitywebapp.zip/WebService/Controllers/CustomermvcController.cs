﻿using ApartmentEntity;
using System.Linq;
using System.Web.Http;
using System.Collections.Generic;
using System;
namespace ApartmentWebApplication.Controllers
{
    //{ bool RegisterCustomer(string mailid, string name, string Password);
    // bool UpdateCustomer(string mailid, string name, string Password);
    // bool CustomerLogin(string mailid, string password);
    // bool deleteCustomer(string mailid);
    //
}
    public class CustomerController : ApiController
    {
      static  DataComponent context = DataFactory.Getcomponent();
        [HttpGet]
        public List<Customer> GetAllCustomers()
        {
            try
            {
                var data = context.GetAllCustomers();
                var custlist = data.Select((C) => new Customer { MailId = C.MailId, Name = C.Name, passwordHash = C.passwordHash, UserId = C.UserId }).ToList();
                return custlist;
            }
            catch (System.Exception)
            {
                return null;
            }
        }
    [HttpPost]
        public bool RegisterCustomer(Customer reg)
        {
            try
            {
                context.RegisterCustomer(reg.MailId, reg.Name, reg.passwordHash);
                return true;
            }
            catch (System.Exception)
            {
                return false;
            }
        }
    [HttpPut]
        public bool UpdateCustomer(Customer update)
        {
            try
            {
                context.UpdateCustomer(update.Name,update.Name,update.passwordHash);
                return true;
            }
            catch (System.Exception)
            {

                return false;
            }
        }
   
        public bool Customerlogin(Customer login)
        {
            try
            {
                context.CustomerLogin(login.MailId, login.passwordHash);
                return true;
            }
            catch (System.Exception)
            {

                return false;
            }

        }
    [HttpDelete]
        public bool Delete( string MailId)
        {
            try
            {
                context.deleteCustomer(MailId);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }


