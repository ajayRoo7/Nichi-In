﻿using ApartmentEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ApartmentWebApplication.Controllers
{
    public class SwimmingController : ApiController
    {
        DataComponent context = DataFactory.Getcomponent();
        [HttpGet]
        public List<Swimming_record> getswimminRecords()
        {
            try
            {
                var data = context.getswimminRecords();
                var allots = data.Select((c) => new Swimming_record { TenantId = c.TenantId, RecordId = c.RecordId, swimming_status = c.swimming_status, Time_and_date = c.Time_and_date }).ToList();

                return allots;
            }
            catch (Exception)
            {
                return null;
            }
        }
        [HttpPost]
        public bool swimming(Swimming_record swim)
        {
            try
            {
                context.swimming(swim.TenantId, swim.swimming_status, swim.Time_and_date);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }

}
