﻿using ApartmentEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Runtime.Remoting.Contexts;
using System.Web.Http;

namespace ApartmentWebApplication.Controllers
{
    public class QueryController : ApiController
    {
        DataComponent context = DataFactory.Getcomponent();
        
        public bool problem(Query qry)
        {
            try
            {
                context.problem(qry.TenantId, qry.query1, qry.service_status);
                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }
        public List<Query> getAllproblems()
        {
            var data = context.getAllproblems();
            var allots = data.Select((c) => new Query { query1=c.query1, QueryId=c.QueryId, service_status=c.service_status , TenantId=c.TenantId }).ToList();

            return allots;
        }
        public bool UpdateQuerytosolve(int id)
        {
            try
            {
                context.UpdateQuerytosolve(id);
                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }
    }
}
