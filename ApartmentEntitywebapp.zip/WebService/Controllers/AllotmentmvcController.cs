﻿using ApartmentEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;

namespace ApartmentWebApplication.Controllers
{
    //{List<Allotment> GetAllotments();
    //bool Allot(int tenantid, int people, int area);
    //bool deleteAllot(int Allotid);
    //bool Allotupdate(int tenantid, int people, int area);
    // }
    public class AllotmentController : ApiController
    {
        DataComponent context = DataFactory.Getcomponent();
        [HttpGet]
        public List<Allotment> GetAllAllotments()
        {
            try
            {
                var data = context.GetAllotments();
                var allots = data.Select((c) => new Allotment { Area_of_Room_in_sqf = c.Area_of_Room_in_sqf, Number_of_people = c.Number_of_people, RoomNo = c.RoomNo, TenantId = c.TenantId }).ToList();

                return allots;

            }
            catch (Exception)
            {
                return null;
            }
        }
        [HttpPost]
        public bool Allot(Allotment allot)
        {
            try
            {
                context.Allot(allot.TenantId, allot.Number_of_people, allot.Area_of_Room_in_sqf);
                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }
        [HttpDelete]
       public  bool deleteAllot(int Allotid)
        {
            try
            {
                context.deleteAllot(Allotid);
                return true; 
            }
            catch (Exception)
            {
                return false;
            }
        }
        [HttpPut]
        bool Allotupdate(Allotment allot)
        {
            try
            {
                context.Allotupdate(allot.TenantId, allot.Number_of_people, allot.Area_of_Room_in_sqf);
                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }
    }
}