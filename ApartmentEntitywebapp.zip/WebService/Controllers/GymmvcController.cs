﻿using ApartmentEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;

namespace ApartmentWebApplication.Controllers
{
    public class GymController : ApiController
    {
        //List<Gym_record> getGymrecords();
        //bool Gym(int tenantid, string status, DateTime date);
        DataComponent context = DataFactory.Getcomponent();
        [HttpGet]
        public List<Gym_record> getGymrecords()
        {
            var data = context.getGymrecords();
            var allots = data.Select((c) => new Gym_record { RecordId=c.RecordId, Gym_status=c.Gym_status, TenantId=c.TenantId, Time_and_date=c.Time_and_date }).ToList();
            return allots;
        }
        [HttpPost]
        public bool Gym(Gym_record gym)
        {
            try
            {
                context.Gym(gym.TenantId, gym.Gym_status, gym.Time_and_date);
                return true;
            }
            catch (Exception)
            {
                return false;         
            }
        }
    }
}
