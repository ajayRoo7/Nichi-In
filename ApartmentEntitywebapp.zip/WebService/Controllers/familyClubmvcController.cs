﻿using ApartmentEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ApartmentWebApplication.Controllers
{
    public class familyClubController : ApiController
    {
        DataComponent context = DataFactory.Getcomponent();
        [HttpGet]
        public List<FamilyClub> getprogrammeRecords()
        {
            var data = context.getprogrammeRecords();
            var allots = data.Select((c) => new FamilyClub { programmeId=c.programmeId, date_Booked=c.date_Booked, date_of_ending=c.date_of_ending, RoomNo=c.RoomNo}).ToList();
            return allots;
        }[HttpPost]
       public bool familyclub(FamilyClub fam)
        {
            try
            {
                context.familyclub(fam.RoomNo, fam.date_Booked, fam.date_of_ending);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
